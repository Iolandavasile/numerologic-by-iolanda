document.querySelector("#app").innerHTML = `
  <div class="container">
    <h1>🔢 Numerologic by Iolanda</h1>
    <p>Selectează limba: 
      <select id="lang">
        <option value="ro" selected>Română</option>
        <option value="fr">Français</option>
      </select>
    </p>

    <input id="name" placeholder="Nume complet" />
    <input id="birth" placeholder="Data nașterii (ex: 23.05.2008)" />
    <button id="calc">Calculează</button>

    <pre id="result"></pre>
  </div>
`;

document.querySelector("#calc").addEventListener("click", () => {
  const lang = document.querySelector("#lang").value;
  const name = document.querySelector("#name").value.trim();
  const date = document.querySelector("#birth").value.trim();

  if (!name || !date) {
    alert(lang === "ro" ? "Introdu numele și data!" : "Entrez le nom et la date !");
    return;
  }

  const message =
    lang === "ro"
      ? `✨ Raport numerologic pentru ${name}\nData nașterii: ${date}\nCalea Vieții: 3 – Creativitate, bucurie și comunicare.`
      : `✨ Rapport numérologique pour ${name}\nDate de naissance: ${date}\nChemin de Vie: 3 – Créativité, joie et communication.`;

  document.querySelector("#result").textContent = message;
});
