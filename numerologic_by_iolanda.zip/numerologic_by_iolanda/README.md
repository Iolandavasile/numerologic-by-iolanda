<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 410 404">
<path fill="#646CFF" d="M399 36L215 392 11 36z"/>
<path fill="#FFCA28" d="M215 392L11 36h388z"/>
</svg>
